const cloud = document.querySelector('.cloud');
const sky = document.querySelector('.sky');

sky.addEventListener('mousemove', (event) => {
  const mouseX = event.clientX;
  const mouseY = event.clientY;

  cloud.style.left = mouseX - cloud.offsetWidth / 2 + 'px';
  cloud.style.top = mouseY - cloud.offsetHeight / 2 + 'px';

  const sun = document.querySelector('.sun');
  const sunRect = sun.getBoundingClientRect();
  const cloudRect = cloud.getBoundingClientRect();

  if (
    cloudRect.left < sunRect.right &&
    cloudRect.right > sunRect.left &&
    cloudRect.top < sunRect.bottom &&
    cloudRect.bottom > sunRect.top
  ) {
    sky.style.backgroundColor = 'darkblue'; // Set the background to dark blue when the cloud covers the sun
  } else {
    sky.style.backgroundColor = '#87CEEB'; // Reset to the initial sky color
  }
});

