

const hoverImage = document.getElementById('hoverImage');
const colorContainer = document.getElementById('colorContainer');

hoverImage.addEventListener('mouseenter', () => {
    colorContainer.style.backgroundColor = 'yellow';
});

hoverImage.addEventListener('mouseleave', () => {
    colorContainer.style.backgroundColor = 'black';
});
